package com.example.teppie.dvdcollector;

import android.test.ActivityInstrumentationTestCase2;

/**
 * Created by teppie on 05/10/15.
 */
public class Test extends ActivityInstrumentationTestCase2{
    public void isConnected(){
        if (Internet.connected == Boolean.TRUE){

        }
    }
}
