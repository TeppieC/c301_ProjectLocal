package com.example.teppie.dvdcollector.Model;

import android.test.ActivityInstrumentationTestCase2;

import junit.framework.TestCase;

/**
 * Created by teppie on 06/10/15.
 */
public class InternetTest extends ActivityInstrumentationTestCase2 {

    public void testIsConnected() throws Exception {

    }

    public void testPushMakeOnline() throws Exception {

    }

    public void testPushTradeOnline() throws Exception {

    }

    public void testCacheOffline() throws Exception {

    }
}