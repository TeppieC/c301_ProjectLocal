package com.example.teppie.dvdcollector.Model;

/**
 * Created by teppie on 05/10/15.
 */
public class Internet {
    private boolean connectability = Boolean.FALSE;

    public boolean isConnected(){
        return this.connectability;
    }

    public void pushMakeOnline(){

    }

    public void pushTradeOnline(){}

    public void cacheOffline(){}
}
